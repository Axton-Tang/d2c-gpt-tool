const baseMixin = {
  mounted() {
    // this.$nextTick(() => {
    //   if (this.$el && typeof this.$el.querySelectorAll === 'function') {
    //     const elements = this.$el.querySelectorAll('uni-view, uni-text');
    //     elements.forEach((el, index) => {
    //       const id = `auto-id_${index}`;
    //       el.setAttribute('data-auto-id', id);
    //     });
    //   }
    // });
  }
}

export default baseMixin;