import {
	createSSRApp
} from "vue";
import App from "./App.vue";
import baseMixin from '@/mixins/index'

export function createApp() {
	const app = createSSRApp(App);

	app.mixin(baseMixin);

	return {
		app,
	};
}
