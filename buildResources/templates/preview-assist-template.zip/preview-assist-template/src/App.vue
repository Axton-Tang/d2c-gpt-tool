<script>
export default {
  globalData: {},
  data() {
    return {
      lastHighlighted: null, // 鼠标移动时，上一次高亮元素
      currentHighlighted: null, // 当前目标高亮元素
    }
  },
  onLaunch: function () {
    console.log('App Launch')
  },
  onShow: function () {
    console.log('App Show')
    document.addEventListener('mousemove', this.handleMouseMove)
    document.addEventListener('click', this.handleGetTargetElement, true)
    window.addEventListener('message', this.handleWatchMessage)
  },
  onHide: function () {
    console.log('App Hide')
    document.removeEventListener('mousemove', this.handleMouseMove)
    document.removeEventListener('click', this.handleGetTargetElement)
    window.removeEventListener('message', this.handleWatchMessage)
  },
  methods: {
    shouldHighlight(element) {
      // 这里可以根据你的需求进行调整
      // 例如，你可以根据元素的 tagName、className 或其他属性来判断
      const tagName = element?.tagName.toLowerCase()
      return ['uni-view', 'uni-text'].includes(tagName) // 只高亮 view 和 text 元素
    },

    shouldFixedHighlight(element) {
      const tagName = element?.tagName.toLowerCase()
      return ['uni-text'].includes(tagName) // 只固定高亮  text 元素
    },

    handleMouseMove(event) {
      const x = event.clientX
      const y = event.clientY

      let elementUnderCursor = document.elementFromPoint(x, y)

      // 如果元素不是需要高亮的元素，并且有父元素，尝试向上查找（此处为了解决 text 元素不会高亮的问题）
      while (elementUnderCursor && !this.shouldHighlight(elementUnderCursor) && elementUnderCursor.parentElement) {
        elementUnderCursor = elementUnderCursor.parentElement
      }

      const classname = this.shouldFixedHighlight(elementUnderCursor) ? 'highlighted-right' : 'highlighted-error'

      // 移除先前高亮的元素的高亮样式
      if (this.lastHighlighted) {
        this.lastHighlighted.classList.remove('highlighted-right')
        this.lastHighlighted.classList.remove('highlighted-error')
      }

      // 为当前元素添加高亮样式
      if (elementUnderCursor && this.shouldHighlight(elementUnderCursor)) {
        elementUnderCursor.classList.add(classname)
        this.lastHighlighted = elementUnderCursor
      }
    },
    handleGetTargetElement(event) {
      let target = event.target
      while (
        target &&
        !target.getAttribute('data-v-reflection-id') &&
        !this.shouldFixedHighlight(target) &&
        target.parentElement
      ) {
        target = target.parentElement
      }
      if (target && this.shouldFixedHighlight(target)) {
        if (this.currentHighlighted) {
          this.currentHighlighted.classList.remove('highlighted-fixed')
        }

        if (this.currentHighlighted === target) {
          this.currentHighlighted = null
        } else {
          target.classList.add('highlighted-fixed')
          this.currentHighlighted = target
        }
        const selctedTextInfo = {
          status: this.currentHighlighted ? true : false,
          path: target.getAttribute('data-v-reflection-file'),
          filename: target.getAttribute('data-v-reflection-title'),
          line: target.getAttribute('data-v-reflection-id')
        }
        console.log("======== 点击的文本信息 =======", selctedTextInfo)
        window.parent.postMessage(selctedTextInfo, "*");
      }
    },
    handleWatchMessage(event) {
      console.log("=======监听到主页面数据", event)
      const { linkedDataSoruce } = event.data;
      if (linkedDataSoruce) {
        this.currentHighlighted.classList.remove('highlighted-fixed')
        this.currentHighlighted.classList.add('linked')
      }
    }
  }
}
</script>

<style lang="less">
/*每个页面公共css */
@import 'static/css/index.css';

.highlighted-error {
  /* 你的高亮样式，例如： */
  border: 2px solid red;
  background: rgba(232, 132, 132, 0.5);
}
.highlighted-right, .highlighted-fixed {
  border: 2px solid rgb(37, 247, 121);
  background: rgba(118, 230, 107, 0.5);
}
.linked {
  border: 2px solid rgb(94, 220, 255);
  background: rgba(41, 216, 240, 0.5);
}
uni-text {
  pointer-events: auto;
}
</style>
