<template>
  <view class="nothing" :style="[customStyle]" v-if="show">
    <image mode="widthFix" :style="{ width: imageSize }" :src="image" />
    <view>{{ description }}</view>
  </view>
</template>

<script>
export default {
  name: 'Empty',
  props: {
    value: Boolean,
    image: {
      type: String,
      default: 'https://static.yunjiglobal.com/healthai/empty-image.png'
    },
    imageSize: {
      type: String,
      default: '320rpx'
    },
    description: {
      type: String,
      default: '暂无数据'
    },
    customStyle: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    show: {
      get() {
        return this.value
      },
      set(val) {
        this.$emit('input', val)
      }
    }
  }
}
</script>

<style lang="less" scoped>
.nothing {
  font-family: PingFangSC-Regular;
  font-size: 26rpx;
  color: #999999;
  text-align: center;
  z-index: 1111;
}
</style>
