<template>
  <he-popup v-model="showModal" v-if="showModal" :border-radius="16" mode="bottom" @close="close" :maskCloseAble="true">
    <div class="container">
      <div class="content" @tap.stop>
          <div class="weChatDesc">
              <div>
                <div class="title">长按扫码添加企业微信</div>
                <div class="title1">更多福利资讯等你来享</div>
                <image 
                  class="iconFont" 
                  src="@/static/images/arrow2.png"
                />
              </div>
              <div class="square flex align-center justify-center">
                <image 
                  class="tipLeftBottom" 
                  src="@/static/images/tipLeftBottom.png"
                />
                
                  <image 
                  class="squareImg"
                                  show-menu-by-longpress="true"
                  :src="qrCode"
                />
                
                <image 
                  class="tipRightTop" 
                  src="@/static/images/tipRightTop.png"
                />
              </div>
          </div>
          <div class="advantage">
              <div class="row">
                <div class="advantageDesc"><image src="@/static/images/circle-tick-icon.png" />专属营养咨询</div>
                <div class="advantageDesc"><image src="@/static/images/circle-tick-icon.png" />私人疾病导诊</div>
              </div>
              <div class="row">
                <div class="advantageDesc"><image src="@/static/images/circle-tick-icon.png" />素材快速生成</div>
                <div class="advantageDesc"><image src="@/static/images/circle-tick-icon.png" />商品问题咨询</div>
              </div>
          </div>
      </div>
    </div>
  </he-popup>
</template>
<script>
import HePopup from '@/components/he-popup.vue'
import http from '../../network/http'

export default {
  components: {
    HePopup
  },
  data() {
    return {
      showModal: false,
      qrCode: ''
      // userInfo: uni.getStorageSync('userInfo') || {}
    }
  },
  created() {
    this.qrCode = uni.getStorageSync('qrCode') || 'https://static.yunjiglobal.com/healthai/wechat-code.jpeg'
    http.contactUs().then(res => {
      if (res.errorCode == 0 && res.data.qrCode) {
        this.qrCode = res.data.qrCode
        uni.setStorageSync('qrCode', this.qrCode)
      }
      console.log(res)
    })
  },
  methods: {
    open() {
      uni.hideTabBar()
      // this.userInfo = uni.getStorageSync('userInfo') || {}
      this.showModal = true
    },
    close() {
      uni.showTabBar()
      this.showModal = false
      this.$emit('close')
    }
  }
}
</script>

<style scoped lang="less">
@import url(../../theme/color.less);
.container {
  .content{
    .weChatDesc {
      position: relative;
      background: linear-gradient(135deg, #00D2AD 0%, #2ED685 96.46%);
      height: 462rpx;
      padding: 144rpx 0 0 40rpx;
    }
    .title {
      color: #FFFFFF;
      font-size: 32rpx;
    }
    .title1 {
      color: #FFFFFF;
      font-size: 26rpx;
      margin: 6rpx 0 24rpx 0;
    }
    .square {
      border-radius:8rpx ;
      width: 264rpx;
      height: 264rpx;
      position: absolute;
      right: 58rpx;
      top: 96rpx;
      background: linear-gradient(223.11deg, rgba(255, 255, 255, 0.4) 2.38%, rgba(255, 255, 255, 0.2) 100.03%);
      .tipRightTop {
        height: 48rpx;
        width: 52rpx;
        position: absolute;
        right: -12rpx;
        top: -40rpx;
      }
      .tipLeftBottom {
        height: 76rpx;
        width: 70rpx;
        position: absolute;
        left: -40rpx;
        bottom: -46rpx;
      }
    }
    .squareImg {
      width: 240rpx;
      height: 240rpx;
      background: #FFFFFF;
    }
    .advantage {
      min-height: 338rpx;
      padding-top: 80rpx;
      display: flex;
      flex-direction: column;
      .row {
        display: flex;
        align-items: center;
        .advantageDesc {
          position: relative;
          color: #666;
          font-size: 28rpx;
          font-weight: 500;
          padding-left: 56rpx;
          margin-bottom: 44rpx;
          display: flex;
          align-items: center;
          image {
            width: 32rpx;
            height: 32rpx;
            margin-right: 24rpx;
          }
          &:last-of-type {
            margin-left: 120rpx;
          }
        }
      }
    }
  }
}
.iconFont{
  height: 48rpx;
  width: 48rpx;
}
.scroll-view {
  max-height:800rpx;
  height: 100%;
}

</style>
