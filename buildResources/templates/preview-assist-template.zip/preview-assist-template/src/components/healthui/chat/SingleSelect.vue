<template>
  <view class="single-select-box">
    <image class="robot-icon" :src="!hideAvatar ? robotAvatar : ''" />
    <view class="question">
      <rich-text :nodes="text" class="questionText"></rich-text>
      <view class="options-container">
        <view
          :class="[
            'item',
            rightIndex >= 0 && selectStatus && selectedIndex === optionIndex && selectedIndex !== rightIndex && 'error',
            rightIndex >= 0 && selectStatus && rightIndex === optionIndex && 'selected',
            selectStatus && selectedIndex === optionIndex && 'selected'
          ]"
          :style="{ width: selectOption.length >= 8 ? '48%' : '100%' }"
          @click="handleClickOption(optionIndex)"
          v-for="(option, optionIndex) of selectOption"
          :key="optionIndex"
        >
          <text class="text">{{ option }}</text>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import { robotAvatar, selectIndexMap, selectLetterMap } from '../constant'

export default {
  props: {
    /**
     * 当前题目信息
     */
    item: {
      type: Object,
      default: () => {
        return {}
      }
    },
    /**
     * 文本
     */
    text: {
      type: String,
      default: () => {
        return ''
      }
    },
    /**
     * 选项
     */
    selectOption: {
      type: Array,
      default: () => {
        return []
      }
    },
    /**
     * 正确答案
     */
    rightAnswer: {
      type: String,
      default: ''
    },
    /**
     * 是否隐藏头像
     */
    hideAvatar: {
      type: Boolean,
      default: () => {
        return false
      }
    }
  },
  data() {
    return {
      robotAvatar,
      selectStatus: 0, // 0: 未选择，1: 已选择
      selectedIndex: -1
    }
  },
  computed: {
    rightIndex() {
      return this.rightAnswer ? selectIndexMap[this.rightAnswer] : -1
    }
  },
  methods: {
    handleClickOption(optionIndex) {
      if (this.selectStatus) {
        return
      }
      this.selectStatus = 1
      this.selectedIndex = optionIndex
      this.$emit('confirm', {
        item: this.item,
        selectedIndex: optionIndex,
        selectedLetter: selectLetterMap[optionIndex],
        selectedText: this.selectOption[optionIndex]
      })
    }
  }
}
</script>

<style scoped lang="less">
.single-select-box {
  display: flex;
  align-items: flex-start;
  position: relative;
  .robot-icon {
    width: 72px;
    height: 72px;
    margin-right: 24px;
  }
  .question {
    padding: 24px 32px;
    background-color: #fff;
    border-radius: 0px 32px 32px 32px;
    min-width: 384px;
    max-width: 544px;
    position: relative;
    margin-bottom: 24px;
    .questionText {
      color: #000;
      font-size: 30px;
      font-style: normal;
      font-weight: 400;
      line-height: 54px;
    }
    .options-container {
      margin-top: 24px;
      animation: fadeIn 0.5s ease-in;
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      .item {
        width: 100%;
        height: 94px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        line-height: 42px;
        background: #fafafa;
        margin-top: 16px;
        padding: 0 24px;
        color: #666;
        &.selected {
          background: #86d483;
          color: #fff;
        }
        &.error {
          background: #fe7575;
          color: #fff;
        }
        .text {
          font-size: 32px;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          text-align: center;
        }
      }
    }
  }
}
</style>