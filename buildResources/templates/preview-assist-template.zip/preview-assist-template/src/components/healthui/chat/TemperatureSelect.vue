<template>
  <view class="temperature-select-box">
    <view class="question-container">
      <image class="robot-icon" :src="!hideAvatar ? robotAvatar : ''" />
      <rich-text :nodes="text" class="questionText"></rich-text>
    </view>
    <view class="temperature-container">
      <view class="temperature">
        <text class="number" :style="{ 'margin-left': ((temperatureValue - 35) / 7) * 100 - 5 + '%' }">{{
          temperatureValue
        }}</text>
        <slider
          class="slider"
          :value="temperatureValue"
          min="35"
          max="42"
          step="0.1"
          activeColor="#8CE4B8"
          backgroundColor="#ccc"
          block-size="20"
          @change="handleSelectTemperature"
          @changing="handleSelectTemperature"
        />
      </view>
      <view class="extra-btn-container">
        <view class="btn">不清楚</view>
        <view class="btn green">确认</view>
      </view>
    </view>
  </view>
</template>

<script>
import { robotAvatar } from '../constant'

export default {
  props: {
    /**
     * 文本
     */
    text: {
      type: String,
      default: () => {
        return ''
      }
    },
    /**
     * 是否隐藏头像
     */
    hideAvatar: {
      type: Boolean,
      default: () => {
        return false
      }
    },
  },
  data() {
    return {
      robotAvatar,
      temperatureValue: '35.6'
    }
  },
  methods: {
    handleSelectTemperature(e) {
      this.temperatureValue = e.detail.value
    }
  }
}
</script>

<style scoped lang="less">
.temperature-select-box {
  display: flex;
  flex-direction: column;
  width: 100vw;
  .question-container {
    display: flex;
    align-items: flex-start;
    .robot-icon {
      width: 72px;
      height: 72px;
      margin-right: 24px;
    }
    .questionText {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      padding: 24px 32px;
      background-color: #fff;
      border-radius: 0px 32px 32px 32px;
      max-width: 544px;
      color: #000;
      font-size: 30px;
      font-style: normal;
      font-weight: 400;
      line-height: 54px;
    }
  }
  .temperature-container {
    margin-top: 16px;
    width: 100%;
    padding: 0 100px;
    display: flex;
    flex-direction: column;
    .temperature {
      .slider {
        width: 100%;
        margin: 20px auto;
      }
    }
    .extra-btn-container {
      display: flex;
      align-items: center;
      margin-top: 24px;
      align-self: flex-end;
      .btn {
        display: flex;
        width: 200px;
        padding: 12px 32px;
        justify-content: center;
        align-items: center;
        gap: 20px;
        border-radius: 92px;
        background: #fff;
        color: #999;
        font-family: PingFang SC;
        font-size: 30px;
        font-style: normal;
        font-weight: 500;
        line-height: 54px;
        &:not(:last-of-type) {
          margin-right: 16px;
        }
        &.green {
          color: #fff;
          background: #86d483;
        }
      }
    }
  }
}
</style>