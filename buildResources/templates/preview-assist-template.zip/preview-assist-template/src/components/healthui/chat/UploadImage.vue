<template>
  <view class="upload-image-box">
    <image class="robot-icon" :src="!hideAvatar ? robotAvatar : ''" />
    <view class="upload-container">
      <view class="upload">
        <view class="header">
          <text class="title">{{ text }}</text>
          <!-- 默认插槽 -->
          <slot name="extra" v-if="showExtraBtn"></slot>
        </view>
        <view class="images-container">
          <view class="image-list">
            <view class="image-wrapper" v-for="(item, index) of imageList" :key="index">
              <image class="image" mode="widthFix" :src="item" />
              <image
                v-if="showExtraBtn"
                class="close-icon"
                src="@/static/images/circle-close-icon-black.png"
                @click="handleDeleteImage(index)"
              />
            </view>
          </view>
          <view class="upload-btn" @click="chooseImage" v-if="showExtraBtn">
            <image class="plus-icon" src="@/static/images/plus-icon-gray.png" />
          </view>
        </view>
        <text class="desc">{{ desc }}</text>
      </view>
      <view class="extra-btn-container" v-if="showExtraBtn">
        <view :class="['btn', extraBtnStatus === 0 && 'green']" @click="handleCancel">{{ cancelText }}</view>
        <view :class="['btn', extraBtnStatus === 1 && 'green']" @click="handleConfirm">确认</view>
      </view>
    </view>
  </view>
</template>

<script>
import { robotAvatar } from '../constant'
import uploadFile from '@/utils/uploadFile'

export default {
  props: {
    /**
     * 文本
     */
    text: {
      type: String,
      default: () => {
        return ''
      }
    },
    /**
     * 描述详情
     */
    desc: {
      type: String,
      default: () => {
        return ''
      }
    },
    /**
     * 取消按钮文本
     */
    cancelText: {
      type: String,
      default: () => {
        return '取消'
      }
    },
    /**
     * 最大上传数量
     */
    maxCount: {
      type: Number,
      default: () => {
        return 3
      }
    },
    /**
     * 是否隐藏头像
     */
    hideAvatar: {
      type: Boolean,
      default: () => {
        return false
      }
    },
    /**
     * 初始化的图片信息
     */
    initImageList: {
      type: Array,
      default: () => {
        return []
      }
    }
  },
  data() {
    return {
      robotAvatar,
      imageList: [],
      showExtraBtn: true,
      extraBtnStatus: -1 // -1：未选， 0: 取消， 1: 确认
    }
  },
  mounted() {
    this.imageList = this.initImageList
  },
  watch: {
    initImageList() {
      this.imageList = this.initImageList
    }
  },
  methods: {
    chooseImage() {
      if (!this.showExtraBtn) {
        return
      }
      var that = this
      if (that.imageList.length >= this.maxCount) {
        uni.showToast({
          title: '最多只能上传' + this.maxCount + '张图片',
          icon: 'none',
          duration: 2000
        })
        return
      }
      uni.chooseImage({
        count: that.maxCount - that.imageList.length,
        sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
        success: async function (res) {
          that.tempFilePaths = res.tempFilePaths
          uni.showLoading({
            title: '正在上传中'
          })
          for (let i = 0; i < res.tempFilePaths.length; i++) {
            const imageUrl = await uploadFile(res.tempFilePaths[i]) // 上传图片
            that.imageList.push(imageUrl)
          }
          that.$emit('upload')
          uni.hideLoading()
        }
      })
    },
    handleDeleteImage(index) {
      if (!this.showExtraBtn) {
        return
      }
      this.imageList.splice(index, 1)
      this.$emit('delete')
    },
    handleConfirm() {
      if (this.extraBtnStatus >= 0 || !this.imageList.length) {
        return
      }
      this.extraBtnStatus = 1
      setTimeout(() => {
        this.showExtraBtn = false
        this.$emit('confirm', this.imageList)
      }, 500)
    },
    handleCancel() {
      if (this.extraBtnStatus >= 0) {
        return
      }
      this.extraBtnStatus = 0
      setTimeout(() => {
        this.showExtraBtn = false
        this.$emit('cancel')
      }, 500)
    }
  }
}
</script>

<style scoped lang="less">
.upload-image-box {
  display: flex;
  align-items: flex-start;
  position: relative;
  .robot-icon {
    width: 72px;
    height: 72px;
    margin-right: 24px;
  }
  .upload-container {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    .upload {
      padding: 24px;
      border-radius: 0 16px 16px 16px;
      background: #fafafa;
      width: 544px;
      height: 318px;
      flex-shrink: 0;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      margin-bottom: 24px;
      .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        width: 100%;
        .title {
          color: #000;
          text-align: center;
          font-feature-settings: 'clig' off, 'liga' off;
          font-family: PingFang SC;
          font-size: 30px;
          font-style: normal;
          font-weight: 600;
          line-height: normal;
        }
      }
      .images-container {
        width: 100%;
        height: 120px;
        overflow-x: scroll;
        overflow-y: hidden;
        display: flex;
        align-items: center;
        padding-top: 24px;
        margin-bottom: 24px;
        box-sizing: content-box;
        flex-shrink: 0;
        .image-list {
          display: flex;
          align-items: center;
          margin-right: 16px;
          .image-wrapper {
            position: relative;
            width: 120px;
            height: 120px;
            &:not(:last-of-type) {
              margin-right: 16px;
            }
            .image {
              width: 100%;
              height: 100%;
            }
            .close-icon {
              position: absolute;
              right: -10px;
              top: -10px;
              width: 22px;
              height: 22px;
            }
          }
        }
        .upload-btn {
          display: flex;
          width: 120px;
          height: 120px;
          padding: 40px;
          justify-content: center;
          align-items: center;
          flex-shrink: 0;
          border-radius: 8px;
          background: #ebebeb;
          .plus-icon {
            width: 40px;
            height: 40px;
            flex-shrink: 0;
          }
        }
      }
      .desc {
        color: #999;
        font-family: PingFang SC;
        font-size: 22px;
        font-style: normal;
        font-weight: 400;
        line-height: normal;
      }
    }
    .extra-btn-container {
      display: flex;
      align-items: center;
      animation: fadeOut 0.5s ease-out;
      .btn {
        display: flex;
        padding: 12px 32px;
        justify-content: center;
        align-items: center;
        gap: 20px;
        border-radius: 92px;
        background: #fff;
        color: #999;
        font-family: PingFang SC;
        font-size: 30px;
        font-style: normal;
        font-weight: 500;
        line-height: 54px;
        &:not(:last-of-type) {
          margin-right: 16px;
        }
        &.green {
          color: #fff;
          background: #86d483;
        }
      }
    }
  }
}
</style>