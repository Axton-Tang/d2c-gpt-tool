<template>
  <view class="muti-select-box">
    <image class="robot-icon" :src="!hideAvatar ? robotAvatar : ''" />
    <view class="question-container">
      <view class="question">
        <rich-text :nodes="text" class="questionText"></rich-text>
        <view class="options-container" v-if="selectOption.length">
          <view
            :class="[
              'item',
              (!selectStatus || !rightIndexList.length) &&
                selectedIndexList.includes(optionIndex) &&
                (selectedStyleType === 0 ? 'selected-border' : 'selected-content'),
              selectStatus &&
                rightIndexList.includes(optionIndex) &&
                (selectedStyleType === 0 ? 'selected-border' : 'selected-content'),
              selectStatus &&
                rightIndexList.length &&
                !rightIndexList.includes(optionIndex) &&
                selectedIndexList.includes(optionIndex) &&
                'error'
            ]"
            :style="{ width: selectOption.length >= 8 ? '48%' : '100%' }"
            @click="handleClickOption(optionIndex)"
            v-for="(option, optionIndex) of selectOption"
            :key="optionIndex"
          >
            <text class="text">{{ option }}</text>
            <image
              v-if="showExtraBtn && showDeleteBtn"
              class="close-icon"
              src="@/static/images/circle-close-icon-black.png"
              @click.stop="handleDeleteItem(optionIndex)"
            />
          </view>
        </view>
        <view class="options-container" v-else>
          <view class="item"
            ><text class="text gray">{{ blankText }}</text></view
          >
        </view>
      </view>
      <view class="extra-btn-container" v-if="showExtraBtn">
        <view :class="['btn', extraBtnStatus === 0 && 'green']" @click="handleCancel" v-if="showCancelBtn">{{ cancelText }}</view>
        <view :class="['btn', extraBtnStatus === 1 && 'green']" @click="handleConfirm">确认</view>
      </view>
    </view>
  </view>
</template>

<script>
import { robotAvatar, selectIndexMap, selectLetterMap } from '../constant'

export default {
  props: {
    /**
     * 当前题目信息
     */
    item: {
      type: Object,
      default: () => {
        return {}
      }
    },
    /**
     * 文本
     */
    text: {
      type: String,
      default: () => {
        return ''
      }
    },
    /**
     * 选项
     */
    selectOption: {
      type: Array,
      default: () => {
        return []
      }
    },
    /**
     * 正确答案
     */
    rightAnswer: {
      type: String,
      default: ''
    },
    /**
     * 是否展示取消按钮
     */
    showCancelBtn: {
      type: Boolean,
      default: () => {
        return false
      }
    },
    /**
     * 取消按钮文本
     */
    cancelText: {
      type: String,
      default: () => {
        return '取消'
      }
    },
    /**
     * 最大选择数量
     */
    maxCount: {
      type: Number,
      default: () => {
        return 9999
      }
    },
    /**
     * 空白数据展示文本，仅在无选项时展示
     */
    blankText: {
      type: String,
      default: () => {
        return '暂无数据'
      }
    },
    /**
     * 是否展示头像
     */
    hideAvatar: {
      type: Boolean,
      default: () => {
        return false
      }
    },
    /**
     * 是否展示删除按钮
     */
    showDeleteBtn: {
      type: Boolean,
      default: () => {
        return false
      }
    },
    /**
     * 选中样式类型，0: 边框高亮， 1: 内容区域高亮
     */
    selectedStyleType: {
      type: Number,
      default: () => {
        return 0
      }
    }
  },
  data() {
    return {
      robotAvatar,
      selectedIndexList: [],
      selectStatus: 0, // 0: 未选择，1: 已选择
      showExtraBtn: true,
      extraBtnStatus: -1 // -1：未选， 0: 取消， 1: 确认
    }
  },
  computed: {
    rightIndexList() {
      return this.rightAnswer ? this.rightAnswer.split('').map((i) => selectIndexMap[i]) : []
    }
  },
  methods: {
    handleClickOption(optionIndex) {
      if (this.selectStatus) {
        return
      }
      if (this.selectedIndexList.includes(optionIndex)) {
        const index = this.selectedIndexList.indexOf(optionIndex)
        this.selectedIndexList.splice(index, 1)
      } else {
        if (this.selectedIndexList.length >= this.maxCount) {
          this.selectedIndexList.shift()
        }
        this.selectedIndexList.push(optionIndex)
      }
    },
    handleConfirm() {
      if (this.extraBtnStatus >= 0 || !this.selectedIndexList.length) {
        return
      }
      this.selectStatus = 1
      this.extraBtnStatus = 1
      setTimeout(() => {
        this.showExtraBtn = false
        this.$emit('confirm', {
          item: this.item,
          selectedIndexList: this.selectedIndexList,
          selectedLetter: this.selectedIndexList.map((i) => selectLetterMap[i]).join(''),
          selectedText: this.selectedIndexList.map((i) => this.selectOption[i]).join('，')
        })
      }, 500)
    },
    handleCancel() {
      if (this.extraBtnStatus >= 0) {
        return
      }
      this.selectStatus = 1
      this.extraBtnStatus = 0
      setTimeout(() => {
        this.showExtraBtn = false
        this.$emit('cancel')
      }, 500)
    },
    handleDeleteItem(optionIndex) {
      this.$emit('delete', optionIndex)
    }
  }
}
</script>

<style scoped lang="less">
.muti-select-box {
  display: flex;
  align-items: flex-start;
  position: relative;
  .robot-icon {
    width: 72px;
    height: 72px;
    margin-right: 24px;
  }
  .question-container {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    .question {
      padding: 24px 32px;
      background-color: #fff;
      border-radius: 0px 32px 32px 32px;
      min-width: 384px;
      max-width: 544px;
      position: relative;
      margin-bottom: 24px;
      .questionText {
        color: #000;
        font-size: 30px;
        font-style: normal;
        font-weight: 400;
        line-height: 54px;
      }
      .options-container {
        margin-top: 24px;
        animation: fadeIn 0.5s ease-in;
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        .item {
          width: 100%;
          height: 94px;
          border-radius: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
          line-height: 42px;
          background: #fafafa;
          margin-top: 16px;
          padding: 0 24px;
          color: #666;
          position: relative;
          &.selected-border {
            border: 2px solid #00da3d;
          }
          &.selected-content {
            background: #86d483;
            color: #fff;
          }
          &.error {
            background: #fe7575;
            color: #fff;
          }
          .text {
            font-size: 32px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
          .gray {
            color: #ccc;
          }
          .close-icon {
            position: absolute;
            right: -6px;
            top: -6px;
            width: 22px;
            height: 22px;
          }
        }
      }
    }
    .extra-btn-container {
      display: flex;
      align-items: center;
      animation: fadeOut 0.5s ease-out;
      .btn {
        display: flex;
        width: 200px;
        padding: 12px 32px;
        justify-content: center;
        align-items: center;
        gap: 20px;
        border-radius: 92px;
        background: #fff;
        color: #999;
        font-family: PingFang SC;
        font-size: 30px;
        font-style: normal;
        font-weight: 500;
        line-height: 54px;
        &:not(:last-of-type) {
          margin-right: 16px;
        }
        &.green {
          color: #fff;
          background: #86d483;
        }
      }
    }
  }
}
</style>