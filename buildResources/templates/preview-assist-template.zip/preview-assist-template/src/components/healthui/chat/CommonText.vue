<template>
  <view class="normal-box">
    <image class="robot-icon" :src="!hideAvatar ? robotAvatar : ''"/>
    <rich-text :nodes="text" class="questionText"></rich-text>
  </view>
</template>

<script>
import { robotAvatar } from '../constant'

export default {
  props: {
    /**
     * 文本
     */
    text: {
      type: String,
      default: () => {
        return ''
      }
    },
    /**
     * 是否隐藏头像
     */
    hideAvatar: {
      type: Boolean,
      default: () => {
        return false
      }
    },
  },
  data() {
    return {
      robotAvatar
    }
  }
}
</script>

<style scoped lang="less">
.normal-box {
  display: flex;
  align-items: flex-start;
  .robot-icon {
    width: 72px;
    height: 72px;
    margin-right: 24px;
  }
  .questionText {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    padding: 24px 32px;
    background-color: #fff;
    border-radius: 0px 32px 32px 32px;
    max-width: 544px;
    color: #000;
    font-size: 30px;
    font-style: normal;
    font-weight: 400;
    line-height: 54px;
    max-width: 480px;
  }
}
</style>