<template>
  <view class="person-form-box">
    <image class="robot-icon" :src="!hideAvatar ? robotAvatar : ''" />
    <view class="form-container">
      <view class="form">
        <view class="question-wrapper">
          <rich-text :nodes="text" class="questionText"></rich-text>
        </view>
        <view class="item-container">
          <view class="item">
            <text class="label">姓名</text>
            <input
              class="input"
              v-model="name"
              :adjust-position="true"
              :cursorSpacing="8"
              placeholder="请输入您的姓名"
              placeholder-style="color: #D6D6D6;"
            />
          </view>
          <view class="item">
            <text class="label">性别</text>
            <radio-group class="radio-group" @change="handleChangeSex">
              <radio value="1" color="#86D483" style="margin-right: 20px">男</radio>
              <radio value="2" color="#86D483">女</radio>
            </radio-group>
          </view>
          <view class="item">
            <text class="label">生日</text>
            <view class="input" @click="handleShowTimeSelect">
              <text class="placeholder" v-if="!timeSelected">请选择出生年月</text>
              <text class="date" v-else
                >{{ dateRange[0][seletedYearIndex] }}年{{ dateRange[1][seletedMonthIndex] }}月</text
              >
              <image class="arrow-right" src="@/static/images/arrow-right-light.png" />
            </view>
          </view>
          <view class="item">
            <text class="label">身高</text>
            <input
              class="input height"
              v-model="height"
              type="digit"
              :adjust-position="true"
              :cursorSpacing="8"
              placeholder="您的身高"
              placeholder-style="color: #D6D6D6;"
            />
            <text class="extra">cm</text>
          </view>
          <view class="item">
            <text class="label">体重</text>
            <input
              class="input weight"
              v-model="weight"
              type="digit"
              :adjust-position="true"
              :cursorSpacing="8"
              placeholder="您的体重"
              placeholder-style="color: #D6D6D6;"
            />
            <text class="extra">kg</text>
          </view>
        </view>
      </view>
      <view class="time-select" v-if="showTimeSelect">
        <picker-view class="picker-view" :value="[seletedYearIndex, seletedMonthIndex]" @change="onPickerChange">
          <view class="rectangle"></view>
          <picker-view-column>
            <view class="item" v-for="(item, index) of dateRange[0]" :key="index">{{ item }}</view>
          </picker-view-column>
          <picker-view-column>
            <view class="item" v-for="(item, index) of dateRange[1]" :key="index">{{ item }}月</view>
          </picker-view-column>
        </picker-view>
      </view>
      <view class="extra-btn-container" v-if="showExtraBtn">
        <view :class="['btn', extraBtnStatus === 0 && 'green']" @click="handleCancel">{{ cancelText }}</view>
        <view :class="['btn', extraBtnStatus === 1 && 'green']" @click="handleConfirm">确认</view>
      </view>
    </view>
  </view>
</template>

<script>
import { robotAvatar } from '../constant'
import { padZero } from '@/utils/index'

export default {
  props: {
    /**
     * 文本
     */
    text: {
      type: String,
      default: () => {
        return ''
      }
    },
    /**
     * 取消按钮文本
     */
    cancelText: {
      type: String,
      default: () => {
        return '取消'
      }
    },
    /**
     * 是否隐藏头像
     */
    hideAvatar: {
      type: Boolean,
      default: () => {
        return false
      }
    }
  },
  data() {
    return {
      robotAvatar,
      showTimeSelect: false,
      showExtraBtn: true,
      name: '',
      sex: 0, // 1：男， 2: 女
      height: '',
      weight: '',
      dateRange: [],
      seletedYearIndex: 0,
      seletedMonthIndex: 0,
      timeSelected: false,
      extraBtnStatus: -1 // -1：未选， 0: 取消， 1: 确认
    }
  },
  created() {
    this.initDateRange()
  },
  computed: {
    isAllowConfirm() {
      return this.name && this.sex && this.timeSelected && this.height && this.weight && !this.showTimeSelect
        ? true
        : false
    }
  },
  methods: {
    initDateRange() {
      let yearRange = []
      let monthRange = []
      // 设置年份范围为1900-2100
      for (let i = 1900; i <= new Date().getFullYear(); i++) {
        yearRange.push(i)
      }
      // 设置月份范围为1-12
      for (let i = 1; i <= 12; i++) {
        monthRange.push(i)
      }
      this.dateRange = [yearRange, monthRange]
      this.$nextTick(() => {
        this.seletedYearIndex = yearRange.length - 1
      })
    },
    handleShowTimeSelect() {
      this.showTimeSelect = !this.showTimeSelect
      this.timeSelected = true
      this.$emit('select')
    },
    onPickerChange(e) {
      this.seletedYearIndex = e.target.value[0]
      this.seletedMonthIndex = e.target.value[1]
    },
    handleChangeSex(e) {
      this.sex = e.detail.value
    },
    handleConfirm() {
      if (this.extraBtnStatus >= 0) {
        return
      }
      if (this.height && !Number(this.height)) {
        uni.showToast({
          title: '身高输入格式错误',
          icon: 'none',
          duration: 2000
        })
        return
      }
      if (this.weight && !Number(this.weight)) {
        uni.showToast({
          title: '体重输入格式错误',
          icon: 'none',
          duration: 2000
        })
        return
      }
      if (this.timeSelected) {
        if (this.isAllowConfirm) {
          this.showTimeSelect = false
          this.extraBtnStatus = 1
          setTimeout(() => {
            this.showExtraBtn = false
            this.$emit('confirm', {
              name: this.name,
              sex: this.sex,
              birthday: `${this.dateRange[0][this.seletedYearIndex]}${padZero(
                this.dateRange[1][this.seletedMonthIndex]
              )}`,
              height: Number(this.height),
              weight: Number(this.weight)
            })
          }, 500)
        } else {
          this.timeSelected = true
          this.showTimeSelect = false
        }
      } else {
        if (this.showTimeSelect) {
          this.timeSelected = true
          this.showTimeSelect = false
        }
      }
    },
    handleCancel() {
      if (this.extraBtnStatus >= 0) {
        return
      }
      this.extraBtnStatus = 0
      setTimeout(() => {
        this.showExtraBtn = false
        this.$emit('cancel')
      }, 500)
    }
  }
}
</script>

<style scoped lang="less">
.person-form-box {
  display: flex;
  align-items: flex-start;
  position: relative;
  .robot-icon {
    width: 72px;
    height: 72px;
    margin-right: 24px;
  }
  .form-container {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    .form {
      padding: 24px 32px;
      background-color: #fff;
      border-radius: 0px 32px 32px 32px;
      min-width: 384px;
      max-width: 544px;
      position: relative;
      margin-bottom: 24px;
      .question-wrapper {
        margin-bottom: 16px;
        .questionText {
          color: #000;
          font-size: 30px;
          font-style: normal;
          font-weight: 400;
          line-height: 54px;
        }
      }
      .item-container {
        display: flex;
        flex-direction: column;
        width: 100%;
        .item {
          width: 100%;
          height: 94px;
          display: flex;
          flex-direction: row;
          align-items: center;
          &:not(:last-of-type) {
            margin-bottom: 16px;
          }
          .label {
            flex-shrink: 0;
            width: 80px;
            color: #666;
            font-family: PingFang SC;
            font-size: 32px;
            font-style: normal;
            font-weight: 500;
            line-height: 54px;
          }
          .input {
            flex: 1;
            width: 100%;
            height: 100%;
            line-height: 100%;
            padding: 16px 32px;
            border-radius: 16px;
            background: #fafafa;
            position: relative;
            .placeholder {
              color: #d6d6d6;
              font-family: PingFang SC;
              font-size: 28px;
              font-style: normal;
              font-weight: 500;
              line-height: 54px;
            }
            .date {
              color: #666;
              font-family: PingFang SC;
              font-size: 28px;
              font-style: normal;
              font-weight: 500;
              line-height: 54px;
            }
            .arrow-right {
              position: absolute;
              right: 16px;
              top: 28px;
              width: 28px;
              height: 28px;
            }
          }
          .weight,
          .height {
            flex: 0.5;
          }
          .extra {
            margin-left: 12px;
            color: #666;
            font-size: 32px;
            font-style: normal;
            font-weight: 500;
            line-height: 54px;
          }
        }
        .radio-group {
          margin-left: 32px;
        }
      }
    }
    .time-select {
      width: 542px;
      height: 332px;
      border-radius: 32px;
      background: #fafafa;
      margin: 32px auto 24px;
      .picker-view {
        width: 100%;
        height: 100%;
        position: relative;
        .rectangle {
          position: absolute;
          width: 4px;
          height: 60px;
          flex-shrink: 0;
          background: #86d483;
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          left: 0;
        }
        :not(:last-of-type) {
          border-right: 2px solid #ebebeb;
        }
        :first-of-type {
          border-top-left-radius: 32px;
          border-bottom-left-radius: 32px;
        }
        :last-of-type {
          border-top-right-radius: 32px;
          border-bottom-right-radius: 32px;
        }
        .item {
          display: flex;
          align-items: center;
          justify-content: center;
        }
      }
    }
    .extra-btn-container {
      display: flex;
      align-items: center;
      animation: fadeOut 0.5s ease-out;
      align-self: flex-end;
      .btn {
        display: flex;
        width: 200px;
        padding: 12px 32px;
        justify-content: center;
        align-items: center;
        gap: 20px;
        border-radius: 92px;
        background: #fff;
        color: #999;
        font-family: PingFang SC;
        font-size: 30px;
        font-style: normal;
        font-weight: 500;
        line-height: 54px;
        &:not(:last-of-type) {
          margin-right: 16px;
        }
        &.green {
          color: #fff;
          background: #86d483;
        }
      }
    }
  }
}
</style>