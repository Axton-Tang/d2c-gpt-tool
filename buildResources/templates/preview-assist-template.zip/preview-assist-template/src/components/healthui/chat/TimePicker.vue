<template>
  <view class="time-select-box">
    <view class="question-container">
      <image class="robot-icon" :src="!hideAvatar ? robotAvatar : ''" />
      <rich-text :nodes="text" class="questionText"></rich-text>
    </view>
    <view class="time-container">
      <view class="time-select">
        <picker-view class="picker-view" indicator-class="picker-view-indicator">
          <view class="rectangle"></view>
          <picker-view-column>
            <view class="item" v-for="number of 60" :key="number">{{ number + 1 }}</view>
          </picker-view-column>
          <picker-view-column>
            <view class="item" v-for="(item, index) of timeUnit" :key="index">{{ item }}</view>
          </picker-view-column>
        </picker-view>
      </view>
      <view class="extra-btn-container">
        <view class="btn">不清楚</view>
        <view class="btn green">确认</view>
      </view>
    </view>
  </view>
</template>

<script>
import { robotAvatar } from '../constant'

export default {
  props: {
    /**
     * 文本
     */
    text: {
      type: String,
      default: () => {
        return ''
      }
    },
    /**
     * 是否隐藏头像
     */
    hideAvatar: {
      type: Boolean,
      default: () => {
        return false
      }
    },
  },
  data() {
    return {
      robotAvatar,
      timeUnit: ['分钟', '小时', '天', '周', '月', '年']
    }
  },
  methods: {}
}
</script>

<style scoped lang="less">
.time-select-box {
  display: flex;
  flex-direction: column;
  width: 100vw;
  .question-container {
    display: flex;
    align-items: flex-start;
    .robot-icon {
      width: 72px;
      height: 72px;
      margin-right: 24px;
    }
    .questionText {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      padding: 24px 32px;
      background-color: #fff;
      border-radius: 0px 32px 32px 32px;
      max-width: 544px;
      color: #000;
      font-size: 30px;
      font-style: normal;
      font-weight: 400;
      line-height: 54px;
    }
  }
  .time-container {
    margin-top: 16px;
    width: 100%;
    padding: 0 100px;
    display: flex;
    flex-direction: column;
    .time-select {
      width: 542px;
      height: 332px;
      border-radius: 32px;
      background: #fafafa;
      margin: 32px auto 24px;
      .picker-view {
        width: 100%;
        height: 100%;
        position: relative;
        .rectangle {
          position: absolute;
          width: 4px;
          height: 60px;
          flex-shrink: 0;
          background: #86d483;
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          left: 0;
        }
        :not(:last-of-type) {
          border-right: 2px solid #ebebeb;
        }
        :first-of-type {
          border-top-left-radius: 32px;
          border-bottom-left-radius: 32px;
        }
        :last-of-type {
          border-top-right-radius: 32px;
          border-bottom-right-radius: 32px;
        }
        .item {
          display: flex;
          align-items: center;
          justify-content: center;
        }
      }
    }
    .extra-btn-container {
      display: flex;
      align-items: center;
      margin-top: 24px;
      align-self: flex-end;
      .btn {
        display: flex;
        width: 200px;
        padding: 12px 32px;
        justify-content: center;
        align-items: center;
        gap: 20px;
        border-radius: 92px;
        background: #fff;
        color: #999;
        font-family: PingFang SC;
        font-size: 30px;
        font-style: normal;
        font-weight: 500;
        line-height: 54px;
        &:not(:last-of-type) {
          margin-right: 16px;
        }
        &.green {
          color: #fff;
          background: #86d483;
        }
      }
    }
  }
}
</style>