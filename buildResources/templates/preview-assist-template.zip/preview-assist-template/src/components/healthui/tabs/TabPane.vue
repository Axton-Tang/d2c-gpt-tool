<template>
  <view v-show="isActive">
    <slot></slot>
  </view>
</template>

<script>
export default {
  props: {
    /**
     * 标签的名字
     */
    name: {
      type: String,
      required: true
    },
    /**
     * 标签的 key（请传 index）
     */
    tabKey: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      isActive: false
    }
  },
  inject: ['tabs'],
  created() {
    if (this.tabs) {
      this.tabs.registerPane({ name: this.name, key: this.tabKey })
    }
  },
  watch: {
    'tabs.activeKey': function (newVal) {
      this.isActive = newVal === this.tabKey ? true : false
    }
  }
}
</script>