<template>
  <view>
    <HeTabs
      :list="panesList"
      :current="activeKey"
      @change="handleSwitchTab"
      activeColor="#000000"
      inactiveColor="#666666"
      fontSize="32"
      :tabsStyle="{ 'border-bottom': '1px solid #EBEBEB' }"
      :barStyle="{ background: '#00A674' }"
    />
    <view class="tabs-content">
      <slot></slot>
    </view>
  </view>
</template>

<script>
import HeTabs from '@/components/he-tabs.vue'

export default {
  data() {
    return {
      activeKey: '',
      panesList: []
    }
  },
  components: {
    HeTabs
  },
  props: {
    /**
     * 默认活跃的标签 key
     */
    defaultActiveKey: {
      type: Number,
      default() {
        return 0
      }
    }
  },
  mounted() {
    this.activeKey = this.defaultActiveKey
  },
  watch: {
    defaultActiveKey() {
      this.activeKey = this.defaultActiveKey
    }
  },
  methods: {
    registerPane(pane) {
      this.panesList.push(pane)
      if (!this.activeKey) this.activeKey = pane.key
    },
    handleSwitchTab(key) {
      this.activeKey = key
      this.$emit('change', key)
    }
  },
  provide() {
    return {
      tabs: this
    }
  }
}
</script>

<style scoped lang="less">
.tabs-content {
}
</style>