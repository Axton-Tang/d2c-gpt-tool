<template>
  <view class="flex-col justify-start items-center confirm-pop" v-if="visible">
    <view class="flex-col section_7 space-y-32">
      <view class="flex-col group_4 space-y-14">
        <text class="self-center font_2">{{ title }}</text>
        <text class="font_1 text_5" v-if="desc">{{ desc }}</text>
      </view>
      <view class="flex-row space-x-10">
        <view
          class="flex-col justify-start items-center cancel-btn"
          :style="cancelBtnStyle + `width: ${this.cancelText ? '120px' : '170px'}`"
          v-if="cancelText"
          @click="onCancel"
          ><text class="font_3 text_6" :style="cancelTextStyle">{{ cancelText }}</text></view
        >
        <view
          class="flex-col justify-start items-center confirm-btn"
         :style="confirmBtnStyle + `width: ${this.confirmText ? '120px' : '170px'}`"
          v-if="confirmText"
          @click="onConfirm"
          ><text class="font_3 text_7" :style="confirmTextStyle">{{ confirmText }}</text></view
        >
      </view>
    </view>
  </view>
</template>

<script>
export default {
  props: {
    /**
     * 是否显示
     */
    visible: {
      type: Boolean,
      default() {
        return false
      }
    },
    /**
     * 标题
     */
    title: {
      type: String,
      default() {
        return ''
      }
    },
    /**
     * 描述信息
     */
    desc: {
      type: String,
      default() {
        return ''
      }
    },
    /**
     * 取消按钮文本
     */
    cancelText: {
      type: String,
      default() {
        return ''
      }
    },
    /**
     * 确认按钮文本
     */
    confirmText: {
      type: String,
      default() {
        return ''
      }
    },
    /**
     * 确认按钮样式
     */
    confirmBtnStyle: {
      type: String,
      default() {
        return ''
      }
    },
    /**
     * 取消按钮样式
     */
    cancelBtnStyle: {
      type: String,
      default() {
        return ''
      }
    },
    /**
     * 确认按钮文本样式
     */
    confirmTextStyle: {
      type: String,
      default() {
        return ''
      }
    },
    /**
     * 取消按钮文本样式
     */
    cancelTextStyle: {
      type: String,
      default() {
        return ''
      }
    }
  },
  data() {
    return {}
  },
  methods: {
    onConfirm() {
      this.$emit("onConfirm")
    },
    onCancel() {
      this.$emit("onCancel")
    }
  }
}
</script>

<style scoped lang="less">
.confirm-pop {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  background-color: #00000099;
  z-index: 150;
  display: flex;
  align-items: center;
  justify-content: center;
  .section_7 {
    padding: 72rpx 40rpx 48rpx;
    background-color: #ffffff;
    border-radius: 24rpx;
    overflow: hidden;
    width: 580rpx;
    .group_4 {
      margin-left: 24rpx;
      margin-right: 32rpx;
      .font_2 {
        font-size: 36rpx;
        font-family: PingFang SC;
        line-height: 50rpx;
        font-weight: 600;
        color: #000000;
      }
      .font_1 {
        font-size: 28rpx;
        font-family: PingFang SC;
        line-height: 34rpx;
      }
      .text_5 {
        color: #999999;
      }
    }
    .space-y-14 {
      & > view:not(:first-child),
      & > text:not(:first-child),
      & > image:not(:first-child) {
        margin-top: 28rpx;
      }
    }
    .space-x-10 {
      & > view:not(:first-child),
      & > text:not(:first-child),
      & > image:not(:first-child) {
        margin-left: 20rpx;
      }
      display: flex;
      align-items: center;
      justify-content: center;
      .cancel-btn {
        padding: 24rpx 0;
        border-radius: 80rpx;
        width: 240rpx;
        height: 76rpx;
        border: solid 2rpx #7199DD;
        .text_6 {
          color: #7199DD;
        }
      }
      .confirm-btn {
        padding: 24rpx 0;
        background: linear-gradient(180deg, #BAD1FF 0%, #7199DD 100%);
        border-radius: 80rpx;
        width: 240rpx;
        height: 76rpx;
        .text_7 {
          color: #ffffff;
        }
      }
      .font_3 {
        font-size: 28rpx;
        font-family: PingFang SC;
        line-height: 26rpx;
        font-weight: 600;
      }
    }
  }
  .space-y-32 {
    & > view:not(:first-child),
    & > text:not(:first-child),
    & > image:not(:first-child) {
      margin-top: 64rpx;
    }
  }
}
</style>