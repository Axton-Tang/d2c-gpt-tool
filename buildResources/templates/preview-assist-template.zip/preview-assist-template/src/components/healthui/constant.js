export const robotAvatar = 'https://static.yunjiglobal.com/healthai/exam-robot.png'

export const selectIndexMap = {
  A: 0,
  B: 1,
  C: 2,
  D: 3,
  F: 4,
  G: 5,
  H: 6,
  J: 7,
  K: 8,
  L: 9,
}

export const selectLetterMap = {
  0: 'A',
  1: 'B',
  2: 'C',
  3: 'D',
  4: 'F',
  5: 'G',
  6: 'H',
  7: 'J',
  8: 'K',
  9: 'L',
}

