<template>
  <view class="content" @click="handleClickItem(detail.lessonId)">
    <image :src="detail.coverUrlSmall" class="coverImg" />
    <view class="right">
      <view class="top">
        <view class="illness-name"
          ><text class="text">{{ detail.illness }}</text
          ><view class="line" v-if="!showProgress"></view
        ></view>
        <text class="course-name">{{ detail.lessonName }}</text>
        <text class="course-intro">{{ detail.lessonBriefIntro }}</text>
      </view>
      <view class="bottom" v-if="showPrice">
        <text class="progress-text" v-if="showProgress">已学{{ detail.studyProgress }}%</text>
        <progress
          class="progress"
          v-if="showProgress"
          :percent="detail.studyProgress"
          backgroundColor="EBEBEB"
          activeColor="#96D1B1"
          stroke-width="4"
        />
        <!-- 已经购买显示 -->
        <view class="price-wrapper" v-if="detail.purchased && !showProgress">
          <view class="label green">课程已购买</view>
        </view>
        <!-- 会员状态下显示 -->
        <view class="price-wrapper" v-else-if="isVip && !showProgress">
          <text class="price delete">￥{{ detail.crossedPrice / 100 || 0 }}</text>
          <view class="label green">会员已解锁</view>
        </view>
        <!-- 未购买时显示 -->
        <view class="price-wrapper" v-else-if="!detail.purchased && !isVip">
          <text class="price">￥{{ detail.price / 100 || 0 }}</text>
          <text class="original-price" v-if="detail.price < detail.crossedPrice">￥{{ detail.crossedPrice / 100 || 0 }}</text>
          <view class="label">会员免费</view>
        </view>
      </view>
      <!-- 只有正在学习才显示的 -->
      <view class="unlock-label" v-if="isVip && showProgress">会员已解锁</view>
    </view>
  </view>
</template>

<script>
export default {
  props: {
    /**
     * 课程详情数据
     */
    detail: {
      type: Object,
      default: () => {
        return {
          lessonId: '',
          coverUrlSmall: '', // 课程封面图
          coverUrlBig: '', // 课程详情封面图
          purchased: false, // 是否已经购买
          crossedPrice: 0, // 划线价
          price: 0, // 价格
          illness: '', //疾病
          lessonBriefIntro: '', // 课程简介
          lessonIntro: '', // 课程介绍
          lessonName: '', // 课程名称
          studyProgress: 0, // 学习进度
          freeForMember: false // 展示会员免费标签
        }
      }
    },
    /**
     * 是否展示学习进度条
     */
    showProgress: {
      type: Boolean,
      default: () => {
        return false
      }
    },
    /**
     * 是否是 vip
     */
    isVip: {
      type: Boolean,
      default: () => {
        return false
      }
    },
    /**
     * 是否展示价格
     */
    showPrice: {
      type: Boolean,
      default: () => {
        return true
      }
    },
    /**
     * 卡片点击后打开页面，0: 介绍页，1: 学习页
     */
    openType: {
      type: Number,
      default: () => {
        return 0 // 0: 介绍页，1: 学习页
      }
    },
  },
  methods: {
    handleClickItem(id) {
      if (this.openType === 1) {
        uni.navigateTo({ url: `/pages/course/study?lessonId=${id}&type=${this.detail.purchased ? 'all' : 'free'}&title=${encodeURIComponent(this.detail.lessonName)}` })
      } else {
        uni.navigateTo({ url: '/pages/course/introduce?lessonId=' + id })
      }
    }
  }
}
</script>

<style scoped lang="less">
.content {
  display: flex;
  align-items: center;
  width: 100%;
  .coverImg {
    width: 200px;
    height: 240px;
    flex-shrink: 0;
    border-radius: 8px;
    background: #d9d9d9;
  }
  .right {
    flex: 1;
    width: 100%;
    height: 240px;
    margin-left: 24px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    position: relative;
    .top {
      display: flex;
      flex-direction: column;
      .illness-name {
        margin-bottom: 4px;
        display: flex;
        align-items: center;
        .text {
          color: #999;
          font-family: PingFang SC;
          font-size: 24px;
          font-style: normal;
          font-weight: 400;
          line-height: 40px;
          flex-shrink: 0;
        }
        .line {
          flex: 1;
          width: 100%;
          height: 2px;
          background: #ebebeb;
          margin-left: 12px;
        }
      }
      .course-name {
        color: #000;
        font-family: PingFang SC;
        font-size: 30px;
        font-style: normal;
        font-weight: 500;
        line-height: 40px;
        margin-bottom: 4px;
        text-overflow: ellipsis;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
      }
      .course-intro {
        color: #999;
        font-family: PingFang SC;
        font-size: 26px;
        font-style: normal;
        font-weight: 400;
        line-height: 40px;
      }
    }
    .bottom {
      display: flex;
      flex-direction: column;
      .progress-text {
        color: #000;
        font-family: PingFang SC;
        font-size: 20px;
        font-style: normal;
        font-weight: 500;
        line-height: 40px;
      }
      .progress {
        width: 100%;
      }
      .price-wrapper {
        display: flex;
        align-items: center;
        margin-top: 12px;
        .price {
          color: #000;
          font-family: PingFang SC;
          font-size: 32px;
          font-style: normal;
          font-weight: 500;
          line-height: 40px;
          &.delete {
            text-decoration: line-through;
            color: #999;
          }
        }
        .original-price {
          margin-left: 4px;
          color: #999;
          font-family: PingFang SC;
          font-size: 24px;
          font-style: normal;
          font-weight: 400;
          line-height: 40px;
          text-decoration: line-through;
        }
        .label {
          margin-left: 16px;
          display: inline-flex;
          padding: 2px 8px;
          justify-content: center;
          align-items: center;
          gap: 10px;
          border-radius: 8px;
          background: #fdedd3;
          color: #e19500;
          font-family: PingFang SC;
          font-size: 26px;
          font-style: normal;
          font-weight: 400;
          line-height: normal;
          &.green {
            background: #C4EFD3;
            color: #42ae00;
          }
        }
      }
    }
    .unlock-label {
      position: absolute;
      right: 0;
      top: 0;
      border-radius: 8px;
      background: #c4efd3;
      display: inline-flex;
      padding: 0px 8px 2px 8px;
      justify-content: center;
      align-items: center;
      gap: 20px;
      color: #42ae00;
      font-family: PingFang SC;
      font-size: 26px;
      font-style: normal;
      font-weight: 400;
      line-height: normal;
    }
  }
}
</style>