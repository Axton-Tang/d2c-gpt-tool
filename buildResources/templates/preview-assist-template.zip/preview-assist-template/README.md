# AI 家庭健康调理师小程序

## 一、简介

大数据部健康管理小程序项目

技术栈：uniapp + vue3 + vite

部署平台：微信小程序（AI家庭健康调理师）

## 二、开发

### 1、安装依赖

```shell
yarn install
```

启动本地开发环境

### 2、启动本地开发环境

```shell
yarn dev:mp-weixin
```

启动成功后，将项目中编译好的文件夹（路径：根目录/dist/dev/mp-weixin）拖到微信开发者工具中打开即可，默认自动带入 appid 等参数，如果没有，说明本地已经添加过项目，直接打开即可。（禁止将开发环境的代码发布到生产环境！）

### 3、打包编译生成环境程序包

```shell
yarn build:mp-weixin
```

编译成功后，将项目中编译好的文件夹（路径：根目录/dist/build/mp-weixin）拖到微信开发者工具中打开即可，默认自动带入 appid 等参数，如果没有，说明本地已经添加过项目，直接打开即可。然后点击上传体验版。

## 三、代码提交规范

Commit message 格式

```shell
<type>(<scope>): <subject>
// 注意冒号 : 后有空格
// 如 feat(miniprogram): 增加了小程序模板消息相关功能
```

type 有以下值

- feat - 新功能 feature
- fix - 修复 bug
- docs - 文档注释
- style - 代码格式(不影响代码运行的变动)
- refactor - 重构、优化(既不增加新功能，也不是修复bug)
- perf - 性能优化
- test - 增加测试
- chore - 构建过程或辅助工具的变动
- revert - 回退